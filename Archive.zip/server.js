const http = require('http');
const app = require('./mts');

const port = process.env.PORT || 8081
const server = http.createServer(app);

server.listen(port);